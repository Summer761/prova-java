function inicio() {
    window.alert(`olá, Mundo!`)
}
function butao() {
    window.alert(`Você clicou no botão!`)
}
function asa() {
    let nome = window.prompt('Qual é o seu nome')
    window.alert(`olá, ${nome} é um prazer ver voce aqui !`)
}
function voar() {
    let n1 = window.prompt('Digite seu nome:')

    let res = document.querySelector('section#res')
    res.innerHTML = `<span>Olá, ${n1}! É um grande prazer te conhecer! 🖖<\span>`
}
function vaar() {
    let n1 = Number(window.prompt('Digite um número:'))

    let res1 = document.querySelector('section#res1')
    res1.innerHTML = `<span> O dobro é ${n1 * 2} e a matade é igual a ${n1 / 2}<\span>`
}
function aaa() {
    let n1 = Number(window.prompt('Digite um número:'))
    let n2 = Number(window.prompt('Digite outro número:'))

    let res2 = document.querySelector('section#res2')
    res2.innerHTML = `<span> A soma entre ${n1} e ${n2} é igual a ${n1 + n2}<\span>`
}
function aa() {
    let nome = window.prompt("Qual o seu nome?")
    let n9 = Number(window.prompt('Digite a primeira nota:'))
    let n10 = Number(window.prompt('Digite a segunda nota:'))

    med = (n9 + n10) / 2

    let res3 = document.querySelector('section#res3')
    res3.innerHTML = `Olá, ${nome}. Sua média foi ${med}`

}
function eles() {
    let nome = window.prompt("Qual o seu nome?")
    let n22 = Number(window.prompt('Digite a primeira nota:'))
    let n23 = Number(window.prompt('Digite a segunda nota:'))

    med = (n22 + n23) / 2

    let res4 = document.querySelector('section#res4')
    res4.innerHTML = `Olá, ${nome}. Sua média foi ${med}, Parabens!`
}
function calcular() {
    let num = Number(window.prompt('Digite um numero: '));
    let res = document.querySelector('section#result');
    res.innerHTML = `<p>O numero a ser analisado aqui sera o <strong>${num}</strong></p>`
    res.innerHTML += `<p>O seu valor absoluto é ${Math.abs(num)}</p>`
    res.innerHTML += `<p>A sua parte inteira é ${Math.trunc(num)}</p>`
    res.innerHTML += `<p>O seu valor inteiro mais proximo é ${Math.round(num)}</p>`
    res.innerHTML += `<p>A sua raiz quadrada é${Math.sqrt(num)}</p>`
    res.innerHTML += `<p>A sua raiz cubica é${Math.cbrt(num)}</p>`
    res.innerHTML += `<p>O valor de ${num} <sup>2</sup> é ${math.pow(num, 2)}</p>`
    res.innerHTML += `<p>O valor de ${num} <sup>3</sup> é ${math.pow(num, 3)}</p>`

}
function contar() {
    contador++;
    res.innerHTML = `<p>${contador}</p>`;
}
function zerar() {
    contador = 0;
    res.innerHTML = null;
}
let contador = 0;
let res = document.querySelector('result');

var resultado = window.document.getElementById('result')

function Acao1() {
    resultado.innerHTML += `<p>Clicou no primeiro botão</p>`
}

function Acao2() {
    resultado.innerHTML += `<p>Clicou no segundo botão</p>`
}
function elas() {
    var n = prompt("Digite um numero");
    var total = n / 2;
    if (n % 2 == 0) {
        alert("Par");
    } else {
        alert("Impar");
    }
}
function menor() {
    var qntNumeros = parseInt(prompt('Quantos números você deseja digitar '));
    var maior = 0;
    var menor = 0;
    var numero;

    for (var i = 0; i < qntNumeros; i++) {
        numero = parseInt(prompt("Digite o número desejado "));

        if (numero > maior) {
            maior = numero;
        }

        if (numero < menor) {
            menor = numero;
        }
    }

    window.alert("O maior número digitado foi: " + maior);
}

function menas() {
    var data = new Date();

    var dia = data.getDate();
    var dia_sem = data.getDay();
    var mes = data.getMonth();
    var ano2 = data.getYear();
    var ano4 = data.getFullYear();
    var hora = data.getHours();
    var min = data.getMinutes();
    var seg = data.getSeconds();
    var mseg = data.getMilliseconds();
    var tz = data.getTimezoneOffset();

    var str_data = dia + '/' + (mes + 1) + '/' + ano4;
    var str_hora = hora + ':' + min + ':' + seg;

    alert('Hoje é ' + str_data + ' às ' + str_hora);
}
function menasa() {
    var data = new Date();

    var dia = data.getDate();
    var dia_sem = data.getDay();
    var mes = data.getMonth();
    var ano2 = data.getYear();
    var ano4 = data.getFullYear();
    var hora = data.getHours();
    var min = data.getMinutes();
    var seg = data.getSeconds();
    var mseg = data.getMilliseconds();
    var tz = data.getTimezoneOffset();

    var str_data = dia + '/' + (mes + 1);
    var str_hora = hora + ':' + min + ':' + seg;

    alert('Hoje é ' + str_data + ' às ' + str_hora);
}

function calcularIdade() {
    var dataNascimento = prompt("Digite sua data de nascimento no formato DD/MM/AAAA:");

    var dataNascimentoObj = new Date(dataNascimento);

    if (isNaN(dataNascimentoObj.getTime())) {
        alert("Data de nascimento inválida. Por favor, digite no formato correto (DD/MM/AAAA).");
        return;
    }

    var dataAtual = new Date();

    var diferencaMilissegundos = dataAtual - dataNascimentoObj;

    var idade = Math.floor(diferencaMilissegundos / (365.25 * 24 * 60 * 60 * 1000));

    alert("Você tem aproximadamente " + idade + " anos.");
}
function gerar() {
    let min = 1
    let max = 100
    let dif = max - min
    let aleatorio = Math.random()
    let num = min + Math.trunc(dif * aleatorio)

    let res = document.querySelector('section#resultade')
    res.innerHTML += `<p>Acabei de pensar no número <mark>${num}</mark>!</p>`
}
function gerarNumeroAleatorio() {
    return Math.floor(Math.random() * 100) + 1;
  }
  
  function jogoDeAdivinhacao() {
    const numeroAleatorio = gerarNumeroAleatorio();
  
    let tentativas = 0;
  
    while (true) {
      const palpite = prompt('Digite um número entre 1 e 100:');
  
      tentativas++;
  
      if (palpite === null) {
        window.alert('Jogo encerrado. Você desistiu!');
        break;
      } else {
        const palpiteNumero = parseInt(palpite);
  
        if (isNaN(palpiteNumero)) {
            window.alert('Por favor, digite um número válido.');
        } else if (palpiteNumero < 1 || palpiteNumero > 100) {
            window.alert('Por favor, digite um número entre 1 e 100.');
        } else if (palpiteNumero < numeroAleatorio) {
            window.alert('Tente um número maior.');
        } else if (palpiteNumero > numeroAleatorio) {
            window.alert('Tente um número menor.');
        } else {
          window.alert(`Parabéns! Você acertou em ${tentativas} tentativas.`);
          break;
        }
      }
    }
  }